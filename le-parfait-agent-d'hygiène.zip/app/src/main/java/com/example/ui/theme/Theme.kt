package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class AppThemeMode {
    SYSTEM, LIGHT, DARK, AMOLED
}

private val DarkColorScheme = darkColorScheme(
    primary = EditorialPrimary,
    onPrimary = EditorialOnPrimary,
    primaryContainer = EditorialPrimaryContainer,
    onPrimaryContainer = EditorialOnPrimaryContainer,
    secondary = EditorialSecondary,
    onSecondary = EditorialOnSecondary,
    secondaryContainer = EditorialSecondaryContainer,
    onSecondaryContainer = EditorialOnSecondaryContainer,
    background = EditorialBackground,
    onBackground = EditorialTextPrimary,
    surface = EditorialSurface,
    onSurface = EditorialTextPrimary,
    surfaceVariant = EditorialSurfaceVariant,
    onSurfaceVariant = EditorialTextMuted,
    outline = EditorialOutline
)

private val AmoledColorScheme = darkColorScheme(
    primary = EditorialPrimary,
    onPrimary = EditorialOnPrimary,
    primaryContainer = EditorialPrimaryContainer,
    onPrimaryContainer = EditorialOnPrimaryContainer,
    secondary = EditorialSecondary,
    onSecondary = EditorialOnSecondary,
    secondaryContainer = EditorialSecondaryContainer,
    onSecondaryContainer = EditorialOnSecondaryContainer,
    background = Color.Black,
    onBackground = EditorialTextPrimary,
    surface = Color(0xFF121416),
    onSurface = EditorialTextPrimary,
    surfaceVariant = Color(0xFF1C1E22),
    onSurfaceVariant = EditorialTextMuted,
    outline = EditorialOutline
)

private val LightColorScheme = lightColorScheme(
    primary = EditorialLightPrimary,
    onPrimary = EditorialLightOnPrimary,
    primaryContainer = EditorialLightPrimaryContainer,
    onPrimaryContainer = EditorialLightOnPrimaryContainer,
    secondary = Color(0xFF2C5E8A),
    secondaryContainer = Color(0xFFD6E3FF),
    background = EditorialLightBackground,
    onBackground = Color(0xFF1A1C1E),
    surface = EditorialLightSurface,
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = EditorialLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF44474E),
    outline = EditorialLightOutline
)

@Composable
fun HygieneTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK, AppThemeMode.AMOLED -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        themeMode == AppThemeMode.AMOLED -> AmoledColorScheme
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
