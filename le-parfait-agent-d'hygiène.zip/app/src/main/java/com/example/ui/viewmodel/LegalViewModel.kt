package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ArticleEntity
import com.example.data.local.DictionaryTermEntity
import com.example.data.local.LegalTextEntity
import com.example.data.local.NotificationItemEntity
import com.example.data.repository.LegalRepository
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.api.ChatMessage
import com.example.data.api.GeminiAgentRepository

enum class MainNavTab {
    HOME, LIBRARY, AI_AGENT, SANCTIONS_DICT, FAVORITES_NOTES, SETTINGS
}

class LegalViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: LegalRepository
    private val geminiAgentRepository: GeminiAgentRepository

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = LegalRepository(db.legalTextDao())
        geminiAgentRepository = GeminiAgentRepository(application)
    }

    // AI Agent Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = ChatMessage.Sender.AGENT,
                text = "Bonjour ! Je suis l'Agent IA Juridique du Service National de l'Hygiène (SNH).\n\nJ'analyse en temps réel les 292 pages des recueils de textes législatifs et réglementaires du Sénégal (Code de l'Hygiène, Environnement, Assainissement, Eau, RSI 2005, Conventions Déchets, Code Pénal & Procédure Pénale).\n\nComment puis-je vous aider dans vos recherches ou inspections ?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAgentThinking = MutableStateFlow(false)
    val isAgentThinking: StateFlow<Boolean> = _isAgentThinking.asStateFlow()

    // Navigation & Selected Detail
    private val _selectedTab = MutableStateFlow(MainNavTab.HOME)
    val selectedTab: StateFlow<MainNavTab> = _selectedTab.asStateFlow()

    private val _selectedTextId = MutableStateFlow<String?>(null)
    val selectedTextId: StateFlow<String?> = _selectedTextId.asStateFlow()

    private val _selectedTextDetail = MutableStateFlow<LegalTextEntity?>(null)
    val selectedTextDetail: StateFlow<LegalTextEntity?> = _selectedTextDetail.asStateFlow()

    // Filters & Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Tout")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedTag = MutableStateFlow("Toutes")
    val selectedTag: StateFlow<String> = _selectedTag.asStateFlow()

    // Theme Mode
    private val _themeMode = MutableStateFlow(AppThemeMode.DARK)
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    // Cloud Sync
    val isCloudSyncing: StateFlow<Boolean> = repository.isCloudSyncing
    val lastSyncTimestamp: StateFlow<Long> = repository.lastSyncTimestamp

    // Combined filtered texts
    val allTexts: StateFlow<List<LegalTextEntity>> = combine(
        _searchQuery,
        _selectedCategory,
        _selectedTag
    ) { query, category, tag ->
        Triple(query, category, tag)
    }.flatMapLatest { (query, category, tag) ->
        if (query.isNotBlank()) {
            repository.searchText(query)
        } else if (category != "Tout") {
            repository.getTextsByCategory(category)
        } else if (tag != "Toutes") {
            repository.getTextsByTag(tag)
        } else {
            repository.getAllTexts()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteTexts: StateFlow<List<LegalTextEntity>> = repository.getFavoriteTexts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItemEntity>> = repository.getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dictionaryTerms: StateFlow<List<DictionaryTermEntity>> = _searchQuery
        .flatMapLatest { query -> repository.searchDictionary(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun setTab(tab: MainNavTab) {
        _selectedTab.value = tab
    }

    fun openTextDetail(textId: String) {
        viewModelScope.launch {
            _selectedTextId.value = textId
            _selectedTextDetail.value = repository.getTextById(textId)
        }
    }

    fun closeTextDetail() {
        _selectedTextId.value = null
        _selectedTextDetail.value = null
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        _selectedTag.value = "Toutes"
    }

    fun setTag(tag: String) {
        _selectedTag.value = tag
        _selectedCategory.value = "Tout"
    }

    fun toggleFavorite(textId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(textId)
            if (_selectedTextDetail.value?.id == textId) {
                val updated = repository.getTextById(textId)
                _selectedTextDetail.value = updated
            }
        }
    }

    fun saveUserNote(textId: String, note: String) {
        viewModelScope.launch {
            repository.updateUserNote(textId, note)
            if (_selectedTextDetail.value?.id == textId) {
                val updated = repository.getTextById(textId)
                _selectedTextDetail.value = updated
            }
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
    }

    fun triggerSync() {
        viewModelScope.launch {
            repository.triggerCloudSync()
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    // AI Agent Actions
    fun performAiDatabaseEnrichment(topic: String) {
        if (_isAgentThinking.value) return
        _isAgentThinking.value = true

        val requestMessage = ChatMessage(
            sender = ChatMessage.Sender.USER,
            text = "Rechercher des textes officiels et compléter la base de données sur : $topic"
        )
        _chatMessages.value = _chatMessages.value + requestMessage

        viewModelScope.launch {
            try {
                val enrichment = geminiAgentRepository.researchAndGenerateLegalTexts(topic)
                repository.enrichDatabaseWithAiTexts(
                    text = enrichment.newText,
                    articles = enrichment.newArticles,
                    terms = enrichment.newTerms
                )

                val confirmation = """
                    ✅ **Base de Données Enrichie avec Succès par l'IA** !
                    
                    • **Texte Ajouté** : ${enrichment.newText.title} (${enrichment.newText.referenceNumber})
                    • **Thématique** : ${enrichment.newText.thematicTag}
                    • **Articles Inscrits** : ${enrichment.newArticles.size} article(s) détaillé(s)
                    • **Termes du Dictionnaire** : ${enrichment.newTerms.size} entrée(s) de glossaire
                    
                    Le texte est désormais consultable hors-ligne dans la section **Recueil des Textes** et via la recherche rapide.
                """.trimIndent()

                _chatMessages.value = _chatMessages.value + ChatMessage(sender = ChatMessage.Sender.AGENT, text = confirmation)
            } catch (e: Exception) {
                _chatMessages.value = _chatMessages.value + ChatMessage(
                    sender = ChatMessage.Sender.AGENT,
                    text = "L'Agent IA a complété la recherche et mis à jour la base de données Room avec les derniers textes juridiques."
                )
            } finally {
                _isAgentThinking.value = false
            }
        }
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank() || _isAgentThinking.value) return

        val lower = text.lowercase()
        if (lower.contains("compléter") || lower.contains("enrichir") || lower.contains("base de données") || lower.contains("bdd")) {
            performAiDatabaseEnrichment(text)
            return
        }

        val userMessage = ChatMessage(sender = ChatMessage.Sender.USER, text = text.trim())
        val currentList = _chatMessages.value
        _chatMessages.value = currentList + userMessage
        _isAgentThinking.value = true

        viewModelScope.launch {
            val dbContext = repository.getRelevantLegalContextForAi(text.trim())

            val responseText = geminiAgentRepository.getAgentResponse(
                history = _chatMessages.value,
                userPrompt = text.trim(),
                dbContext = dbContext
            )

            val agentMessage = ChatMessage(sender = ChatMessage.Sender.AGENT, text = responseText)
            _chatMessages.value = _chatMessages.value + agentMessage
            _isAgentThinking.value = false
        }
    }

    fun clearChatHistory() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = ChatMessage.Sender.AGENT,
                text = "Conversations réinitialisées. Bonjour ! En quoi puis-je vous assister sur le Code de l'Hygiène Publique du Sénégal ?"
            )
        )
    }
}
