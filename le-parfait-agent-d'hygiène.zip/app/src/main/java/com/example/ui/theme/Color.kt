package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Aesthetic Palette
val EditorialBackground = Color(0xFF1A1C1E)
val EditorialSurface = Color(0xFF232629)
val EditorialSurfaceVariant = Color(0xFF2E3033)
val EditorialOutline = Color(0xFF44474E)

val EditorialPrimary = Color(0xFFD1E1FF)
val EditorialOnPrimary = Color(0xFF002F64)
val EditorialPrimaryContainer = Color(0xFF3B4858)
val EditorialOnPrimaryContainer = Color(0xFFD1E1FF)

val EditorialSecondary = Color(0xFFAAC7FF)
val EditorialOnSecondary = Color(0xFF00315D)
val EditorialSecondaryContainer = Color(0xFF334455)
val EditorialOnSecondaryContainer = Color(0xFFD1E1FF)

val EditorialTextPrimary = Color(0xFFE2E2E6)
val EditorialTextSecondary = Color(0xFF909196)
val EditorialTextMuted = Color(0xFFC2C6CF)

// Light Editorial Palette (Crisp High-Contrast Editorial)
val EditorialLightBackground = Color(0xFFF7F9FC)
val EditorialLightSurface = Color(0xFFFFFFFF)
val EditorialLightSurfaceVariant = Color(0xFFEDF1F7)
val EditorialLightOutline = Color(0xFFC5CEE0)
val EditorialLightPrimary = Color(0xFF003865)
val EditorialLightOnPrimary = Color(0xFFFFFFFF)
val EditorialLightPrimaryContainer = Color(0xFFD1E1FF)
val EditorialLightOnPrimaryContainer = Color(0xFF001D36)

val PenaltyRed = Color(0xFFBA1A1A)
val PenaltyRedContainer = Color(0xFFFFDAD6)
val SuccessGreen = Color(0xFF4CAF50)

