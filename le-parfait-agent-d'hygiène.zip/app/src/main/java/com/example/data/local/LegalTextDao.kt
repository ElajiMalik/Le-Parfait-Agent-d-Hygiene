package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LegalTextDao {

    @Query("SELECT * FROM legal_texts ORDER BY publicationYear DESC, title ASC")
    fun getAllLegalTexts(): Flow<List<LegalTextEntity>>

    @Query("SELECT * FROM legal_texts WHERE category = :category ORDER BY title ASC")
    fun getTextsByCategory(category: String): Flow<List<LegalTextEntity>>

    @Query("SELECT * FROM legal_texts WHERE thematicTag = :tag ORDER BY title ASC")
    fun getTextsByTag(tag: String): Flow<List<LegalTextEntity>>

    @Query("SELECT * FROM legal_texts WHERE isFavorite = 1")
    fun getFavoriteTexts(): Flow<List<LegalTextEntity>>

    @Query("SELECT * FROM legal_texts WHERE id = :textId")
    suspend fun getTextById(textId: String): LegalTextEntity?

    @Query("""
        SELECT * FROM legal_texts 
        WHERE title LIKE '%' || :query || '%' 
           OR summary LIKE '%' || :query || '%' 
           OR fullContent LIKE '%' || :query || '%'
           OR referenceNumber LIKE '%' || :query || '%'
        ORDER BY title ASC
    """)
    fun searchText(query: String): Flow<List<LegalTextEntity>>

    @Query("""
        SELECT * FROM legal_texts 
        WHERE title LIKE '%' || :query || '%' 
           OR summary LIKE '%' || :query || '%' 
           OR fullContent LIKE '%' || :query || '%'
           OR referenceNumber LIKE '%' || :query || '%'
        ORDER BY title ASC
    """)
    suspend fun searchTextOnce(query: String): List<LegalTextEntity>

    @Query("SELECT * FROM legal_texts ORDER BY publicationYear DESC, title ASC")
    suspend fun getAllLegalTextsOnce(): List<LegalTextEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTexts(texts: List<LegalTextEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertText(text: LegalTextEntity)

    @Update
    suspend fun updateText(text: LegalTextEntity)

    // Articles
    @Query("SELECT * FROM articles WHERE textId = :textId ORDER BY articleId ASC")
    fun getArticlesForText(textId: String): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE content LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%' OR articleNumber LIKE '%' || :query || '%'")
    fun searchArticles(query: String): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE content LIKE '%' || :query || '%' OR title LIKE '%' || :query || '%' OR articleNumber LIKE '%' || :query || '%'")
    suspend fun searchArticlesOnce(query: String): List<ArticleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticles(articles: List<ArticleEntity>)

    // Notifications
    @Query("SELECT * FROM notifications ORDER BY id DESC")
    fun getAllNotifications(): Flow<List<NotificationItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationItemEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: String)

    // Dictionary Terms
    @Query("SELECT * FROM dictionary_terms WHERE term LIKE '%' || :query || '%' OR definition LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY term ASC")
    fun searchDictionary(query: String): Flow<List<DictionaryTermEntity>>

    @Query("SELECT * FROM dictionary_terms WHERE term LIKE '%' || :query || '%' OR definition LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY term ASC")
    suspend fun searchDictionaryOnce(query: String): List<DictionaryTermEntity>

    @Query("SELECT * FROM dictionary_terms ORDER BY term ASC")
    fun getAllDictionaryTerms(): Flow<List<DictionaryTermEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDictionaryTerms(terms: List<DictionaryTermEntity>)
}
