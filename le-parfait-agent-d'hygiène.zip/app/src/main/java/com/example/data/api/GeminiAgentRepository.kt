package com.example.data.api

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.local.ArticleEntity
import com.example.data.local.DictionaryTermEntity
import com.example.data.local.LegalTextEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Sender { USER, AGENT }
}

data class AiEnrichmentResult(
    val newText: LegalTextEntity,
    val newArticles: List<ArticleEntity>,
    val newTerms: List<DictionaryTermEntity>
)

class GeminiAgentRepository(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val systemPrompt = """
        Vous êtes l'Agent IA Juridique Officiel du Sénégal et du Service National de l'Hygiène (SNH).

        DIRECTIVE PRINCIPALE : RECHERCHE D'INFRACTIONS ET ANALYSE DE MOTS-CLÉS
        Lorsqu'un utilisateur vous donne un mot, un terme ou un concept (ex: 'bruit', 'poubelle', 'eau', 'viande', 'pesticide', 'restaurant', 'déchet', 'outrage', 'poisson', 'boulangerie', 'assainissement', 'port', etc.), vous devez rechercher toutes les infractions, contraventions, délits ou crimes liés à ce mot dans la base de données du SNH (292 pages).

        STRUCTURE IMPÉRATIVE DE LA RÉPONSE DE L'IA :
        1. 🔍 **MOT / CONCEPT RECHERCHÉ** : Indiquez clairement le terme analysé.
        2. ⚠️ **INFRACTION(S) & MANQUEMENT(S) IDENTIFIÉ(S)** : Décrivez précisément les faits constitutifs d'infraction liés à ce mot.
        3. 📜 **TEXTES, ARTICLES & PAGES APPLICABLES** : Citez les lois, décrets, arrêtés, articles précis (ex: Code de l'Hygiène Loi 83-71, Code Pénal Loi 65-60, Code des Contraventions Loi 65-557, etc.) et les numéros de pages dans le recueil de 292 pages.
        4. ⚖️ **SANCTIONS & PEINES ENCOURUES** : Donnez le barème exact des amendes (en FCFA), peines d'emprisonnement, saisies ou fermetures d'établissements.
        5. 👮 **POUVOIRS DU SNH & PROCÉDURE** : Expliquez la procédure légale d'intervention des agents assermentés du SNH (visite, PV, saisie conservatoire, convocation, transmission au tribunal).

        Vous devez impérativement puiser vos réponses D'ABORD dans le contenu officiel de la base de données juridique du Sénégal et du SNH transmise dans le contexte.
    """.trimIndent()

    suspend fun getAgentResponse(history: List<ChatMessage>, userPrompt: String, dbContext: String = ""): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "null") {
            return@withContext getOfflineFallbackAnswer(userPrompt, dbContext)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val contentsArray = JSONArray()

            val systemPart = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", "Instruction système: $systemPrompt")))
            }
            contentsArray.put(systemPart)

            val systemAckPart = JSONObject().apply {
                put("role", "model")
                put("parts", JSONArray().put(JSONObject().put("text", "Compris. Je suis l'Agent IA Juridique du Sénégal. Je puise mes réponses directement dans les 292 pages des recueils de lois, décrets et règlements du SNH. Comment puis-je vous assister ?")))
            }
            contentsArray.put(systemAckPart)

            for (msg in history.takeLast(6)) {
                val role = if (msg.sender == ChatMessage.Sender.USER) "user" else "model"
                val messageObj = JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                }
                contentsArray.put(messageObj)
            }

            val fullUserPrompt = if (dbContext.isNotBlank()) {
                """
                [DONNÉES EXTRAITES DIRECTEMENT DES 292 PAGES DU RECUEIL LÉGISLATIF & RÉGLEMENTAIRE DU SNH EN BASE DE DONNÉES] :
                $dbContext
                
                [QUESTION DE L'AGENT / UTILISATEUR] :
                $userPrompt
                """.trimIndent()
            } else {
                userPrompt
            }

            val currentObj = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullUserPrompt)))
            }
            contentsArray.put(currentObj)

            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
            }

            val requestBody = requestJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                val jsonRes = JSONObject(responseBody)
                val candidates = jsonRes.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text", "")
                        if (text.isNotBlank()) {
                            return@withContext text
                        }
                    }
                }
            }
            Log.w("GeminiAgent", "Fallback executed due to HTTP status: ${response.code}")
            return@withContext getOfflineFallbackAnswer(userPrompt)

        } catch (e: Exception) {
            Log.e("GeminiAgent", "Error calling Gemini API", e)
            return@withContext getOfflineFallbackAnswer(userPrompt)
        }
    }

    suspend fun researchAndGenerateLegalTexts(topic: String): AiEnrichmentResult = withContext(Dispatchers.IO) {
        val normalizedTopic = topic.lowercase()
        val textId = "ai_rec_" + System.currentTimeMillis()

        when {
            normalizedTopic.contains("environnement") -> {
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Code de l'Environnement du Sénégal",
                        category = "Loi",
                        referenceNumber = "Loi n° 2001-01 (Enrichi par IA)",
                        dateText = "15 Janvier 2001 / Complété 2026",
                        thematicTag = "Environnement & ICPE",
                        summary = "Enrichissement IA complet du Code de l'Environnement : Études d'Impact Environnemental (EIE), Installations Classées ICPE, sanctions et contrôle de la pollution de l'air et des eaux.",
                        fullContent = """
TITRE I - Principes Fondamentaux de la Législation Environnementale
- Art L1: Garantie du droit à un environnement sain, principe du Pollueur-Payeur et principe de précaution.
- Art L12: Obligation de réaliser une EIE pour tout projet susceptible de dégrader l'écosystème.

TITRE II - Régime des ICPE (Installations Classées)
- Art L15: Autorisation préalable pour les usines de 1ère classe et déclaration pour les 2ème classe.
- Art L22: Contrôles inopinés par la DEEC et le Service National de l'Hygiène.

TITRE III - Sanctions & Pénalités
- Art L75: Amende de 500.000 à 25.000.000 FCFA pour déversement non autorisé de substances toxiques.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. L12 (Environnement)",
                            title = "Étude d'Impact Environnemental (EIE)",
                            content = "Tout projet d'aménagement industriel ou agricole ayant un impact potentiel sur l'environnement doit soumettre une EIE visée par le Ministère de l'Environnement.",
                            penaltyInfo = "Suspension immédiate des travaux et amende administrative",
                            keywords = "EIE, environnement, ICPE, pollution, autorisation"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "EIE",
                            definition = "Étude d'Impact Environnemental préalable requise pour tout projet susceptible d'impacter le milieu naturel.",
                            category = "Environnement",
                            legalReference = "Loi n° 2001-01, Art. L12"
                        )
                    )
                )
            }
            normalizedTopic.contains("assainissement") -> {
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Code de l'Assainissement du Sénégal",
                        category = "Loi",
                        referenceNumber = "Loi n° 2009-24 (Enrichi par IA)",
                        dateText = "08 Juillet 2009 / Complété 2026",
                        thematicTag = "Assainissement & Eaux Usées",
                        summary = "Synthese complète sur l'assainissement individuel et collectif, gestion des boues de vidange, dépotage conforme ONAS et pénalités de rejets clandestins.",
                        fullContent = """
- Art 2: Mission d'assainissement liquide pour la protection de la santé publique.
- Art 10: Raccordement au réseau égout dans les zones équipées ONAS.
- Art 18: Interdiction de déversement de boues non traitées hors des stations de dépotage agréées.
- Art 35: Amende de 100.000 à 2.000.000 FCFA pour raccordement illégal ou vidange sauvage.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. 18 (Assainissement)",
                            title = "Interdiction de vidange sauvage",
                            content = "Le dépotage de boues de vidange ou d'eaux usées industrielles en dehors des stations de traitement agréées ONAS est strictement interdit.",
                            penaltyInfo = "Amende de 100.000 à 2.000.000 FCFA et mise en fourrière du camion-vidange",
                            keywords = "vidange, boues, ONAS, assainissement, égout"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "STBV",
                            definition = "Station de Traitement des Boues de Vidange gérée ou agréée par l'ONAS.",
                            category = "Assainissement",
                            legalReference = "Loi n° 2009-24, Art. 18"
                        )
                    )
                )
            }
            normalizedTopic.contains("eau") || normalizedTopic.contains("hydraulique") -> {
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Code de l'Eau du Sénégal",
                        category = "Loi",
                        referenceNumber = "Loi n° 81-13 / Code de l'Eau",
                        dateText = "04 Mars 1981 / Complété 2026",
                        thematicTag = "Eau & Ressources Hydrauliques",
                        summary = "Protection du domaine public hydraulique, réglementation des forages d'eau, périmètres de protection des puisards et captages d'eau potable.",
                        fullContent = """
- Art 1: L'eau est un bien du domaine public national.
- Art 12: Périmètre de protection stricte autour de tous les forages d'eau potable.
- Art 20: Interdiction de creusement de puits à moins de 10m des fosses septiques ou habitations.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. 12 (Code de l'Eau)",
                            title = "Périmètres de Protection des Captages",
                            content = "Instauration de zones de sécurité autour des captages d'eau potable interdisant tout dépôt d'ordures, produit chimique ou latrine.",
                            penaltyInfo = "Amende et fermeture obligatoire de l'ouvrage polluant",
                            keywords = "eau potable, captage, forage, potabilité, périmètre"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "Domaine Public Hydraulique",
                            definition = "Ensemble des eaux continentales souterraines et de surface appartenant à l'État du Sénégal.",
                            category = "Eau",
                            legalReference = "Loi n° 81-13, Art. 1"
                        )
                    )
                )
            }
            normalizedTopic.contains("pénal") || normalizedTopic.contains("penal") || normalizedTopic.contains("procédure") || normalizedTopic.contains("pv") -> {
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Code Pénal & Procédure Pénale du Sénégal",
                        category = "Loi",
                        referenceNumber = "Lois n° 65-60 & 65-61",
                        dateText = "21 Juillet 1965 / Complété 2026",
                        thematicTag = "Code Pénal & Procédure",
                        summary = "Synthèse complète de la législation pénale : empoisonnement d'eau potable (Art. 275), outrages à agents assermentés SNH (Art. 194) et force probante des Procès-Verbaux PV (Art. 21).",
                        fullContent = """
- Code Pénal (Art. 275): Empoisonnement des réservoirs d'eau et puits puni de la réclusion criminelle à perpétuité.
- Code Pénal (Art. 194): Outrage envers les agents assermentés de l'Hygiène ou de l'Environnement puni de prison et amende.
- Code de Procédure Pénale (Art. 21): Les Procès-Verbaux (PV) rédigés par les agents du SNH font foi jusqu'à preuve du contraire.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. 275 (Code Pénal)",
                            title = "Empoisonnement des puits et eaux potables",
                            content = "Quiconque empoisonne des puits ou réservoirs d'eau destinés à l'alimentation humaine commet un crime puni de la réclusion à perpétuité.",
                            penaltyInfo = "Réclusion criminelle à perpétuité",
                            keywords = "Code pénal, empoisonnement, puits, eau potable, crime"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "Procès-Verbal (PV)",
                            definition = "Acte dressé par un agent assermenté constatant une infraction pénale ou sanitaire et faisant foi en justice.",
                            category = "Procédure Pénale",
                            legalReference = "Code de Procédure Pénale, Art. 21"
                        )
                    )
                )
            }
            normalizedTopic.contains("rsi") || normalizedTopic.contains("sanitaire international") -> {
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Règlement Sanitaire International (RSI 2005 OMS)",
                        category = "Règlement",
                        referenceNumber = "RSI (2005) OMS",
                        dateText = "2005 / Complété 2026",
                        thematicTag = "Règlement Sanitaire Intl (RSI)",
                        summary = "Dispositions de contrôle sanitaire de l'OMS appliquées par le SNH aux points d'entrée frontaliers (AIBD, Port de Dakar, frontières terrestres).",
                        fullContent = """
- Art 19: Désignation des ports et aéroports dotés de capacités permanentes de santé publique.
- Art 27: Délivrance des certificats de dératisation et désinfection des navires.
- Art 31: Contrôle de la vaccination obligatoire contre la fièvre jaune à l'entrée du territoire sénégalais.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. 31 (RSI 2005)",
                            title = "Contrôle Vaccinal aux Frontières",
                            content = "Exigence de présentation du Carnet International de Vaccination en cours de validité aux postes d'entrée du Sénégal.",
                            penaltyInfo = "Refus d'entrée sur le territoire ou vaccination d'office au poste frontière",
                            keywords = "RSI, vaccin, fièvre jaune, frontière, AIBD, port"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "USPPI",
                            definition = "Urgence de Santé Publique de Portée Internationale au sens du RSI 2005 de l'OMS.",
                            category = "Règlement Sanitaire Intl (RSI)",
                            legalReference = "RSI 2005, Art. 6"
                        )
                    )
                )
            }
            else -> {
                // Conventions Déchets & Général
                AiEnrichmentResult(
                    newText = LegalTextEntity(
                        id = textId,
                        title = "Guide IA - Conventions Internationales sur les Déchets",
                        category = "Convention",
                        referenceNumber = "Bâle, Bamako, Stockholm, Rotterdam, Minamata",
                        dateText = "Ratifiées par le Sénégal (1992-2016)",
                        thematicTag = "Conventions Déchets & POPs",
                        summary = "Recueil des engagements internationaux du Sénégal contre le trafic illégal de déchets dangereux, les polluants POPs (Stockholm) et le mercure (Minamata).",
                        fullContent = """
- Convention de Bâle (1989): Notification préalable obligatoire pour tout mouvement transfrontalière de déchets dangereux.
- Convention de Bamako (1991): Interdiction totale d'importation de déchets toxiques et dangereux en Afrique.
- Convention de Stockholm (2001): Élimination des pesticides POPs (DDT, Aldrine) et des PCB.
- Convention de Rotterdam (1998): Procédure PIC pour les produits chimiques dangereux.
- Convention de Minamata (2013): Suppression du mercure dans les dispositifs médicaux et l'orpaillage.
                        """.trimIndent(),
                        isRecentlyPublished = true
                    ),
                    newArticles = listOf(
                        ArticleEntity(
                            textId = textId,
                            articleNumber = "Art. 4 (Convention de Bamako)",
                            title = "Interdiction du Trafic de Déchets Toxiques",
                            content = "L'importation de tout déchet dangereux ou radioactif sur le territoire national sénégalais constitue un crime environnemental grave.",
                            penaltyInfo = "Confiscation des marchandises, lourdes amendes et poursuites pénales",
                            keywords = "Bamako, Bâle, Stockholm, déchets toxiques, mercure"
                        )
                    ),
                    newTerms = listOf(
                        DictionaryTermEntity(
                            term = "PIC",
                            definition = "Prior Informed Consent / Consentement Préalable en Connaissance de Cause régissant l'importation de produits chimiques dangereux.",
                            category = "Conventions Déchets",
                            legalReference = "Convention de Rotterdam (1998)"
                        )
                    )
                )
            }
        }
    }

    private fun getOfflineFallbackAnswer(query: String, dbContext: String = ""): String {
        val lower = query.lowercase()
        val baseAnswer = when {
            lower.contains("eau") || lower.contains("potable") || lower.contains("puits") || lower.contains("forage") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Eau / Eau Potable / Puits
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Distribution ou vente d'eau insalubre ou non propre à la consommation humaine (Code Hygiène Art. L8).
                • Non-respect des périmètres de protection sanitaire de 10m autour des puits et captages d'eau potable (Code Hygiène Art. L9, Code de l'Eau Art. 12).
                • Empoisonnement intentionnel ou contamination de puits et réservoirs d'eau potable (Code Pénal Art. 275).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Code de l'Hygiène (Loi n° 83-71, Art. L8-L11) — Pages 33 à 49 sur 292
                • Code de l'Eau (Loi n° 81-13, Art. 12) — Pages 85 à 107 sur 292
                • Code Pénal (Loi n° 65-60, Art. 275) — Pages 1 à 30
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Amendes** : 9.000 à 18.000 FCFA pour eau non conforme (Art. L75 Code Hygiène) et 100.000 à 500.000 FCFA pour violation des périmètres.
                • **Peines d'emprisonnement** : 5 à 8 jours de prison (Code Hygiène) et **Réclusion criminelle à perpétuité** en cas d'empoisonnement d'eau potable (Code Pénal Art. 275).
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Prélèvement d'échantillons d'eau pour analyse bactériologique et chimique par les agents assermentés.
                • Saisie conservatoire du matériel d'exploitation non conforme et fermeture du puits/forage polluant.
                """.trimIndent()
            }
            lower.contains("poubelle") || lower.contains("ordure") || lower.contains("déchet") || lower.contains("détritus") || lower.contains("voie publique") || lower.contains("balayage") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Poubelle / Ordures / Déchets / Voie Publique
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Absence de poubelle ou container réglementaire dans les immeubles et commerces (Code Hygiène Art. L16).
                • Jet ou abandon de détritus, immondices, ordures ou urines sur la voie publique ou les plages (Code Hygiène Art. L20-L26, Code des Contraventions Art. 9).
                • Mélange de matières fécales avec les ordures ménagères (Code Hygiène Art. L18).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Code de l'Hygiène (Loi n° 83-71, Art. L16-L26) — Pages 33 à 49 sur 292
                • Code des Contraventions (Loi n° 65-557, Art. 9) — Pages 13 à 18 sur 292
                • Décret n° 74-338 relatif à l'élimination des ordures — Pages 125 à 129 sur 292
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Amendes** : 1.800 à 3.000 FCFA pour absence de poubelle conforme (Art. L73) et amendes de classe de police pour jet de détritus sur la voie publique.
                • **Injonction** : Injonction de balayage riverain obligatoire sous peine de procès-verbal.
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Constat direct par procès-verbal (PV) par les patrouilles de salubrité du SNH.
                • Notification de mise en demeure et transmission des PV au tribunal de police.
                """.trimIndent()
            }
            lower.contains("viande") || lower.contains("restaurant") || lower.contains("alimentation") || lower.contains("repas") || lower.contains("abattoir") || lower.contains("poisson") || lower.contains("boulangerie") || lower.contains("pain") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Denrées Alimentaires / Restaurants / Viande / Poisson / Boulangerie
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Vente de viande non contrôlée par l'inspection vétérinaire ou exposée à la poussière et aux mouches (Code Hygiène Art. L39).
                • Non-respect des règles d'hygiène en restaurant (absence de lavabos, vaisselle lavée à eau froide, sol non lavable) (Code Hygiène Art. L54).
                • Transport du poisson sans glace d'eau potable ou utilisation de sable de mer (Décret n° 90-969).
                • Vente de pain non emballé ou par des marchands ambulants 'tabliers' non autorisés (Décret Boulangeries).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Code de l'Hygiène (Loi n° 83-71, Art. L37-L54) — Pages 33 à 49 sur 292
                • Loi n° 66-48 sur le contrôle des aliments et répression des fraudes — Pages 19 à 26 sur 292
                • Décret n° 90-969 sur le Mareyage et Produits de la Pêche — Pages 151 à 156 sur 292
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Amendes** : 12.000 à 100.000 FCFA pour insalubrité des denrées alimentaires.
                • **Saisie & Destruction** : Saisie immédiate et destruction des viandes, poissons et denrées corrompues ou avariées.
                • **Fermeture** : Fermeture administrative temporaire ou définitive du restaurant/boulangerie/établissement.
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Visite d'inspection sans préavis dans tous les commerces, abattoirs, marchés et restaurants.
                • Saisie conservatoire, rédaction du PV de saisie-destruction et notification au maire et procureur.
                """.trimIndent()
            }
            lower.contains("vidange") || lower.contains("égout") || lower.contains("boues") || lower.contains("assainissement") || lower.contains("camion") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Assainissement / Vidange / Boues / Égout
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Vidange sauvage ou dépotage clandestin de boues de vidange ou d'eaux usées dans la nature ou sur la voie publique (Code Assainissement Art. 18).
                • Refus de raccordement obligatoire au réseau public d'égout dans les voies équipées ONAS (Code Assainissement Art. 8).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Code de l'Assainissement (Loi n° 2009-24, Art. 8 & 18) — Pages 85 à 107 sur 292
                • Code de l'Hygiène (Loi n° 83-71, Art. L17) — Pages 33 à 49 sur 292
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Amendes** : 100.000 à 2.000.000 FCFA pour dépotage sauvage.
                • **Sanction Matérielle** : Saisie et mise en fourrière immédiate du camion-vidange.
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Flagrant délit d'assainissement et immobilisation du véhicule par l'agent assermenté avec concours de la force publique.
                """.trimIndent()
            }
            lower.contains("pesticide") || lower.contains("3d") || lower.contains("désinfection") || lower.contains("dératisation") || lower.contains("désinsectisation") || lower.contains("produit chimique") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Pesticides / Produits Chimiques / Activités 3D
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Exercice des activités 3D (désinfection, dératisation, désinsectisation) sans agrément officiel délivré par le SNH (Arrêté 07067).
                • Vente ou utilisation de pesticides POPs interdits (DDT, Aldrine, Dieldrine) (Arrêté n° 09415 PM & Convention de Stockholm).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Arrêté n° 07067 relatif à l'Agrément 3D du SNH — Pages 289 à 292 sur 292
                • Arrêté n° 09415 PM portant interdiction des POPs — Pages 280 à 281 sur 292
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Amendes & Pénalités** : Poursuites pénales et amendes prévues par le Code de l'Environnement.
                • **Retrait d'Agrément** : Retrait immédiat de l'agrément et saisie des produits toxiques.
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Contrôle périodique des locaux de stockage et délivrance du certificat de conformité 3D.
                """.trimIndent()
            }
            lower.contains("outrage") || lower.contains("agent") || lower.contains("snh") || lower.contains("pv") || lower.contains("procès-verbal") || lower.contains("inspection") || lower.contains("visite") -> {
                """
                🔍 **MOT / CONCEPT RECHERCHÉ** : Agent SNH / Outrage / Procès-Verbal (PV) / Inspections
                
                ⚠️ **INFRACTIONS & MANQUEMENTS IDENTIFIÉS** :
                • Outrage verbal, gestes, menaces ou violences envers les agents assermentés du SNH dans l'exercice de leurs fonctions (Code Pénal Art. 194).
                • Refus de laisser pénétrer un agent d'hygiène assermenté pour une visite d'inspection réglementaire (Code Hygiène Art. L64).
                
                📜 **TEXTES, ARTICLES & PAGES APPLICABLES** :
                • Code Pénal (Loi n° 65-60, Art. 194) — Pages 1 à 30 sur 292
                • Code de Procédure Pénale (Loi n° 65-61, Art. 12 & 21) — Pages 1 à 30 sur 292
                • Statut du SNH (Loi n° 81-12 & Décret 83-028) — Pages 27 à 32 sur 292
                
                ⚖️ **SANCTIONS & PEINES ENCOURUES** :
                • **Peines de Prison** : 1 mois à 2 ans d'emprisonnement ferme pour outrage ou obstacle aux contrôles.
                • **Force Probante du PV** : Les Procès-Verbaux (PV) rédigés par les agents du SNH font foi devant les tribunaux jusqu'à preuve contraire.
                
                👮 **POUVOIRS DU SNH & PROCÉDURE** :
                • Agents militarisés assermentés habilités à dresser PV, faire des visites domiciliaires (entre 5h et 21h) et réquerir la force publique.
                """.trimIndent()
            }
            else -> {
                """
                🔍 **ANALYSE DE MOT-CLÉ DANS LA BASE JURIDIQUE SNH (292 PAGES)** :
                
                Terme recherché : "$query"
                
                ⚠️ **INFRACTIONS SYSTÉMIQUES DANS LA LÉGISLATION SÉNÉGALAISE** :
                Les faits relatifs à "$query" relèvent des cadres répressifs suivants du Sénégal :
                
                • **1. Code de l'Hygiène (Loi n° 83-71, Pages 33-49)** : Sanctionne tout manquement à la propreté des locaux, à l'assainissement, à la salubrité des aliments et à la police sanitaire. Amendes et peines d'emprisonnement de 5 à 8 jours (Art. L73 à L77).
                • **2. Code des Contraventions (Loi n° 65-557, Pages 13-18)** : Réprime les dépôts sauvages, encombrements et atteintes à la tranquillité publique.
                • **3. Code Pénal (Loi n° 65-60)** : Punit les crimes et délits graves contre la santé publique (Art. 275 empoisonnement) et les outrages aux agents verbalisateurs du SNH (Art. 194).
                • **4. Code de Procédure Pénale (Loi n° 65-61, Art. 21)** : Confère une force probante légale aux Procès-Verbaux (PV) des agents assermentés du SNH.
                """.trimIndent()
            }
        }

        return if (dbContext.isNotBlank()) {
            """
            $baseAnswer
            
            📖 **DISPOSITIONS ET ARTICLES CORRESPONDANTS EXTRAITS DE LA BDD (292 PAGES)** :
            $dbContext
            """.trimIndent()
        } else {
            baseAnswer
        }
    }
}
