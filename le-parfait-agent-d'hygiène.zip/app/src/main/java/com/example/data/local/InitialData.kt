package com.example.data.local

object InitialData {

    suspend fun seedDatabase(dao: LegalTextDao) {
        val texts = listOf(
            // --- 1. HYGIÈNE ---
            LegalTextEntity(
                id = "loi_83_71",
                title = "Code de l'Hygiène du Sénégal",
                category = "Loi",
                referenceNumber = "Loi n° 83-71",
                dateText = "05 Juillet 1983",
                thematicTag = "Hygiène & Salubrité",
                summary = "Règles générales d'hygiène publique : contrôle de l'eau, habitations, voies publiques, plages, installations industrielles, denrées alimentaires, boissons, police de l'hygiène et pénalités.",
                fullContent = """
TITRE PREMIER - Règles d'hygiène publique
CHAPITRE I - Lutte contre les épidémies et vaccinations
- Art L1: Immunisation obligatoire (tuberculose, diphtérie, tétanos, poliomyélite) pour le personnel des établissements de soins.
- Art L2-L3: Déclaration obligatoire de toute maladie contagieuse par les médecins et chefs de famille.
- Art L4: Désinfection obligatoire exécutée par le Service National de l'Hygiène.

CHAPITRE II - Règles d'hygiène concernant l'eau
- Art L8: Obligation de fournir une eau propre à la consommation humaine et interdiction d'utiliser de l'eau non potable.
- Art L9: Périmètres de protection autour des puits (implantés à 10m au moins des habitations) et sources.
- Art L10: Protection des ouvrages de captage, réservoirs couvercle et désinfection obligatoire.
- Art L11: Conditions de conformité des puits (margelle 50cm, dalles étanches).

CHAPITRE III - Hygiène des habitations
- Art L16: Conservation des ordures ménagères dans des poubelles ou containers réglementaires.
- Art L17: Élimination des matières usées liquides par systèmes d'assainissement agréés.
- Art L18: Interdictions strictes : mélange matières fécales avec ordures, récipients formant gîtes à moustiques.

CHAPITRE IV & V - Voies publiques et Plages
- Art L20-L26: Interdiction de jeter des détritus, urines ou eaux usées sur la voie publique. Obligation de balayage riverain.
- Art L27-L29: Interdiction des animaux, circulation de véhicules et abandon de déchets sur les plages.

CHAPITRE VII - Denrées alimentaires & Restaurants
- Art L37: Salubrité des ateliers de préparation et magasins d'alimentation.
- Art L39: Vente de viande contrôlée par l'inspection vétérinaire et protégée de la poussière/mouches.
- Art L42: Aménagement des magasins : aération, sol dur lavable 1/jour, réfrigération des denrées altérables.
- Art L54: Hygiène des restaurants : locaux lavables, lavabos équipés, lavage vaisselle eau chaude.

TITRE II & III - Police de l'Hygiène et Pénalités
- Art L60: Compétence des officiers, sous-officiers et agents d'hygiène assermentés pour constater les infractions.
- Art L64: Visites domiciliaires autorisées entre 5h et 21h (à toute heure avec assentiment ou flagrant délit).
- Art L73 à L77: Échelle des amendes et peines d'emprisonnement applicables selon la gravité de l'infraction.
                """.trimIndent(),
                pageRange = "Pages 33 à 49 sur 292",
                startPage = 33,
                endPage = 49,
                isFavorite = true,
                userNote = "Texte fondamental pour le Service National de l'Hygiène."
            ),
            LegalTextEntity(
                id = "loi_65_557",
                title = "Code des Contraventions de la République du Sénégal",
                category = "Loi",
                referenceNumber = "Loi n° 65-557",
                dateText = "21 Juillet 1965",
                thematicTag = "Code Pénal & Procédure",
                summary = "Code régissant les peines de police (emprisonnement, amende, confiscation) applicables aux contraventions de salubrité publique, d'hygiène, d'encombrement des rues, de nuisances et d'animaux.",
                fullContent = """
DISPOSITIONS PRÉLIMINAIRES
- Art 1: Peines de police (emprisonnement 1 à 30 jours, amende de 200 à 20.000 FCFA, confiscation des objets).
- Art 8 (Sureté et tranquillité publiques): Sanctions pour dépôt de détritus ou objets dangereux dans les lieux publics, omission de nettoyage des rues, tapages nocturnes, obstruction.
- Art 9 (Hygiène et Santé publiques): Sanctions pour étalage sans autorisation sur la voie publique, racolage ou affichage contraire à la décence.
- Art 10 (Voirie et circulation): Sanctions pour dépôt sans nécessité de matériaux encombrant la voie publique, absence d'éclairage des chantiers.
- Art 14: Confiscation des marchandises exposées illégalement ou poids/mesures fausses.
                """.trimIndent(),
                pageRange = "Pages 13 à 18 sur 292",
                startPage = 13,
                endPage = 18
            ),
            LegalTextEntity(
                id = "loi_66_48",
                title = "Contrôle des Produits Alimentaires & Répression des Fraudes",
                category = "Loi",
                referenceNumber = "Loi n° 66-48",
                dateText = "27 Mai 1966",
                thematicTag = "Alimentation",
                summary = "Réglementation de la fabrication, transformation et vente des produits alimentaires. Sanctions contre les tromperies, falsifications, produits corrompus ou toxiques.",
                fullContent = """
TITRE PREMIER - Contrôle des produits alimentaires
- Art 1: Soumission à autorisation administrative et contrôle officiel des produits destinés à l'alimentation.
- Art 3: Saisie et destruction des produits insalubres ou non conformes.
- Art 6-9: Sanctions d'emprisonnement et d'amende pour fabrication ou vente sans autorisation ou refus de contrôle.
- Art 10-13: Répression de la tromperie sur la qualité, la quantité ou l'origine, et saisie des denrées falsifiées.
- Art 21: Pouvoir de pénétration des agents assermentés dans tous magasins, entrepôts, abattoirs et marchés.
                """.trimIndent(),
                pageRange = "Pages 19 à 26 sur 292",
                startPage = 19,
                endPage = 26
            ),
            LegalTextEntity(
                id = "loi_81_12",
                title = "Statut du Personnel du Service National de l'Hygiène",
                category = "Loi",
                referenceNumber = "Loi n° 81-12",
                dateText = "04 Mars 1981",
                thematicTag = "Statut SNH",
                summary = "Organisation du cadre militarisé des agents du Service National de l'Hygiène (SNH). Répartition en 5 corps, droits, devoirs, discipline et assermentation.",
                fullContent = """
- Art 1: Mission du SNH : Éducation des populations, contrôle de la législation hygiénique, constatation des infractions, surveillance aux frontières.
- Art 2: Répartition en 5 corps hiérarchisés (officiers, techniciens supérieurs, sous-officiers, agents, auxiliaires).
- Art 8: Devoirs militarisés : Inéligibilité, interdiction du droit de grève et de syndicat.
- Art 16-19: Discipline rigoureuse, soumission à l'obéissance hiérarchique et échelle des sanctions disciplinaires.
                """.trimIndent(),
                pageRange = "Pages 27 à 32 sur 292",
                startPage = 27,
                endPage = 32
            ),
            LegalTextEntity(
                id = "loi_94_44",
                title = "Code de Justice Militaire du Sénégal",
                category = "Loi",
                referenceNumber = "Loi n° 94-44",
                dateText = "27 Mai 1994",
                thematicTag = "Statut SNH",
                summary = "Code régissant les juridictions militaires et la discipline applicable aux forces armées et corps paramilitaires (SNH, Police, Douanes, Parcs).",
                fullContent = """
- Art 1-4: Compétence des juridictions ordinaires à formation spéciale pour connaître des infractions militaires et disciplinaires des forces armées et corps paramilitaires renvoyés par leurs statuts (SNH).
- Art 44-48: Pouvoirs de police judiciaire militaire, visites d'inspection et poursuites sur ordre de l'autorité compétente.
- Art 106-184: Sanctions des infractions contre le devoir, la discipline et les consignes.
                """.trimIndent(),
                pageRange = "Pages 50 à 84 sur 292",
                startPage = 50,
                endPage = 84
            ),
            LegalTextEntity(
                id = "loi_2002_28",
                title = "Homologation des Pesticides dans les États du CILSS",
                category = "Loi",
                referenceNumber = "Loi n° 2002-28",
                dateText = "09 Décembre 2002",
                thematicTag = "Pesticides & 3D",
                summary = "Ratification de la Réglementation commune aux États membres du CILSS sur l'homologation des pesticides, instaurant le Comité Sahélien des Pesticides (CSP).",
                fullContent = """
- Art 1-3: Réglementation de l'autorisation, la mise sur le marché, l'utilisation et le contrôle des matières actives et formulés de pesticides au Sahel.
- Art 6: Comité Sahélien des Pesticides (CSP) chargé d'évaluer les dossiers d'homologation et d'octroyer les Autorisations Provisoires de Vente (APV).
- Art 8: Interdiction de commercialiser ou d'utiliser un pesticide non homologué par le CSP.
- Art 19-20: Normes d'étiquetage, d'emballage et d'avertissement toxicologique.
                """.trimIndent(),
                pageRange = "Pages 85 à 107 sur 292",
                startPage = 85,
                endPage = 107
            ),
            LegalTextEntity(
                id = "loi_2010_09",
                title = "Police des Ports Maritimes du Sénégal",
                category = "Loi",
                referenceNumber = "Loi n° 2010-09",
                dateText = "23 Avril 2010",
                thematicTag = "Hygiène & Salubrité",
                summary = "Règles de sécurité, sûreté et salubrité portuaire (Port Autonome de Dakar). Interdiction des déversements toxiques, des jetés d'ordures dans le plan d'eau et contrôle par la police sanitaire.",
                fullContent = """
- Art 2: Protection des eaux portuaires : interdiction de jeter des ordures, décombres ou de verser des liquides insalubres dans les eaux du port ou sur les quais.
- Art 13: Constatation des infractions par les officiers de port, officiers de police judiciaire et agents de la police sanitaire.
- Art 23: Sanctions pénales et amendes pour entrave aux contrôles ou pollution portuaire.
                """.trimIndent(),
                pageRange = "Pages 108 à 117 sur 292",
                startPage = 108,
                endPage = 117
            ),
            LegalTextEntity(
                id = "decret_68_508",
                title = "Constatation des Infractions sur les Produits Alimentaires",
                category = "Décret",
                referenceNumber = "Décret n° 68-508",
                dateText = "07 Mai 1968",
                thematicTag = "Alimentation",
                summary = "Procédure d'inspection, de prélèvement d'échantillons et de saisies des denrées corrompues ou falsifiées par les agents assermentés de l'Hygiène et du contrôle économique.",
                fullContent = """
- Art 3: Compétence des agents assermentés du Service d'Hygiène pour prélever des échantillons, effectuer des saisies ou interdire la mise en vente.
- Art 4: Libre accès des inspecteurs aux magasins, entrepôts, abattoirs, gares, ports et marchés.
- Art 9-12: Procédure de prélèvement scellé sous anonymat pour analyse en laboratoire.
                """.trimIndent(),
                pageRange = "Pages 119 à 124 sur 292",
                startPage = 119,
                endPage = 124
            ),
            LegalTextEntity(
                id = "decret_74_338",
                title = "Évacuation et Dépôt des Ordures Ménagères",
                category = "Décret",
                referenceNumber = "Décret n° 74-338",
                dateText = "10 Avril 1974",
                thematicTag = "Hygiène & Salubrité",
                summary = "Définition des ordures ménagères, conditions de mise en poubelles étanches, balayage des voies publiques et aménagement des décharges contrôlées.",
                fullContent = """
- Art 1-2: Définition globale des ordures ménagères et résidus d'établissements.
- Art 5: Obligation pour chaque immeuble d'utiliser des récipients étanches clos d'une contenance maximale de 100 litres.
- Art 7: Interdiction formelle de jeter des cadavres d'animaux ou ordures à moins de 35m des habitations, puits ou cours d'eau.
- Art 10-17: Modalités d'exploitation des décharges contrôlées (couverture de terre de 10 à 30cm, absence de chiffonnage non autorisé, clôture).
                """.trimIndent(),
                pageRange = "Pages 125 à 129 sur 292",
                startPage = 125,
                endPage = 129
            ),
            LegalTextEntity(
                id = "decret_76_018",
                title = "Vente sur la Voie et dans les Lieux Publics",
                category = "Décret",
                referenceNumber = "Décret n° 76-018",
                dateText = "06 Janvier 1976",
                thematicTag = "Alimentation",
                summary = "Réglementation du commerce ambulant et des marchands dits 'tabliers'. Cartes professionnelles, interdiction de vente de denrées devant les écoles/hôpitaux et salubrité des étals.",
                fullContent = """
- Art 2-4: Interdiction de la vente ambulante non autorisée et soumission des marchands 'tabliers' à autorisation et carte professionnelle.
- Art 10: Interdiction de vente de denrées alimentaires sur la voie publique devant les écoles, hôpitaux et dispensaires.
- Art 11: Dérogations pour les fruits, pain, pâtisseries, boissons fraîches sous réserve d'hygiène stricte.
                """.trimIndent(),
                pageRange = "Pages 130 à 133 sur 292",
                startPage = 130,
                endPage = 133
            ),
            LegalTextEntity(
                id = "decret_83_028",
                title = "Application du Statut du Personnel du Service National de l'Hygiène",
                category = "Décret",
                referenceNumber = "Décret n° 83-028",
                dateText = "05 Janvier 1983",
                thematicTag = "Statut SNH",
                summary = "Modalités d'application du statut militarise du SNH : conditions de recrutement (taille, acuité visuelle), port obligatoire de l'uniforme, notation annuelle, discipline et tenue.",
                fullContent = """
- Art 3: Conditions physiques d'aptitude (taille minimale 1,70m, acuité visuelle 15/10e, constitution robuste).
- Art 6: Port obligatoire de l'uniforme régulier et interdiction d'actes discréditant le service.
- Art 14: Hiérarchie des corps (Officiers, Techniciens Supérieurs, Sous-officiers, Agents, Auxiliaires).
- Art 48-56: Système de notation annuelle et punitions d'ordre intérieur (consigne, arrêts simples, arrêts de rigueur).
                """.trimIndent(),
                pageRange = "Pages 134 à 150 sur 292",
                startPage = 134,
                endPage = 150
            ),
            LegalTextEntity(
                id = "decret_90_969",
                title = "Conditions Techniques de la Pratique du Mareyage",
                category = "Décret",
                referenceNumber = "Décret n° 90-969",
                dateText = "05 Septembre 1990",
                thematicTag = "Alimentation",
                summary = "Prescriptions techniques et hygiéniques pour les ateliers de mareyage, navires de pêche et véhicules de transport de poissons. Utilisation d'eau potable, glace et hygiène du personnel.",
                fullContent = """
- Art 2-3: Aménagement des ateliers (murs lisses lavables sur 1,75m, sol antidérapant avec pente d'écoulement, eau potable sous pression).
- Art 6: Examen médical obligatoire du personnel manipulateur et hygiène vestimentaire.
- Art 12: Transport obligatoire du poisson sous couche de glace fabriquée avec de l'eau potable (interdiction du sable de mer).
                """.trimIndent(),
                pageRange = "Pages 151 à 156 sur 292",
                startPage = 151,
                endPage = 156
            ),
            LegalTextEntity(
                id = "decret_90_1159",
                title = "Règlement de Discipline Générale dans les Forces Armées",
                category = "Décret",
                referenceNumber = "Décret n° 90-1159",
                dateText = "12 Octobre 1990",
                thematicTag = "Statut SNH",
                summary = "Décret fixant le règlement de discipline générale, la hiérarchie militaire, les devoirs des militaires, le salut, l'uniforme et le barème des punitions applicables au SNH.",
                fullContent = """
- Art 1-5: Principes de la discipline militaire, obéissance aux ordres et hiérarchie des grades.
- Art 39-42: Règles de port de l'uniforme réglementaire et tenue civile.
- Art 79-97: Classification des fautes disciplinaires et compétences pour infliger des sanctions.
                """.trimIndent(),
                pageRange = "Pages 157 à 220 sur 292",
                startPage = 157,
                endPage = 220
            ),
            LegalTextEntity(
                id = "decret_2006_1261",
                title = "Hygiène et Sécurité dans les Établissements de Toute Nature",
                category = "Décret",
                referenceNumber = "Décret n° 2006-1261",
                dateText = "15 Novembre 2006",
                thematicTag = "Hygiène & Salubrité",
                summary = "Règles générales de sécurité et de santé au travail : aération des locaux, propreté quotidienne, vestiaires, douches, toilettes séparées et fourniture de boissons hygiéniques.",
                fullContent = """
- Art 3-5: Locaux de travail à l'abri des inondations, infiltrations et insalubrités. Aération et ventilation garanties.
- Art 9-11: Nettoyage quotidien des planchers, désinfection des surfaces et évacuation au fur et à mesure des résidus.
- Art 12-16: Fourniture gratuite de 2 tenues de travail par an, vestiaires individuels et douches aménagées.
- Art 33-37: Nombre minimum de cabinets d'aisance par tranche d'effectifs avec eau limpide et savon.
                """.trimIndent(),
                pageRange = "Pages 228 à 238 sur 292",
                startPage = 228,
                endPage = 238
            ),
            LegalTextEntity(
                id = "decret_2008_1007",
                title = "Gestion des Déchets Biomédicaux au Sénégal",
                category = "Décret",
                referenceNumber = "Décret n° 2008-1007",
                dateText = "18 Août 2008",
                thematicTag = "Déchets Biomédicaux",
                summary = "Réglementation de la chaîne de gestion des déchets biomédicaux (DASRI, piquants/tranchants, anatomiques). Tri à la source, transport inviolable, traitement par incinération 800°C et traçabilité.",
                fullContent = """
- Classification officielle:
  1. Déchets ménagers et assimilés
  2. DASRI (Infectieux)
  3. Déchets anatomiques
  4. Piquants et tranchants (Boîtes de sécurité)
  5. Déchets pharmaceutiques & spéciaux
- Obligations des producteurs: Tri obligatoire à la source sur le lieu de génération avec code couleur.
- Stockage: Local aéré, sécurisé, décontaminé 1 fois/semaine. Durée max < 48 heures.
- Transport: Conteneurs de type GRV (Grand Récipient pour Vrac) hermétiques et inviolables.
- Traitement: Incinération à température minimale de 800°C ou stérilisation/broyage.
- Agrément: Obligation d'obtention de l'agrément ministériel SNH avec traçabilité complète.
                """.trimIndent(),
                pageRange = "Pages 239 à 245 sur 292",
                startPage = 239,
                endPage = 245,
                isFavorite = true
            ),
            LegalTextEntity(
                id = "decret_2019_2277",
                title = "Réglementation de la Boulangerie et des Pâtisseries",
                category = "Décret",
                referenceNumber = "Décret n° 2019-2277",
                dateText = "31 Décembre 2019",
                thematicTag = "Alimentation",
                summary = "Encadrement des activités de production, distribution et vente de pain et pâtisseries au Sénégal. Règles d'hygiène (toques, blouses, lavages des mains, visites médicales) et emballages.",
                fullContent = """
- Art 3-4: Soumission de l'ouverture de toute boulangerie à autorisation préalable du Ministère du Commerce.
- Art 9: Règles strictes d'hygiène : port de toques/blouses, ongles et cheveux courts, visites médicales périodiques.
- Art 11: Interdiction de la vente de pain par les marchands 'tabliers' ou restaurateurs de rue.
                """.trimIndent(),
                pageRange = "Pages 266 à 270 sur 292",
                startPage = 266,
                endPage = 270
            ),
            LegalTextEntity(
                id = "arrete_09415_pm",
                title = "Interdiction des Pesticides et Produits Chimiques POPs",
                category = "Arrêté",
                referenceNumber = "Arrêté n° 09415 PM",
                dateText = "06 Novembre 2008",
                thematicTag = "Pesticides & 3D",
                summary = "Arrêté primatorial interdisant l'importation, la production et l'utilisation des pesticides POPs (DDT, Aldrine, Dieldrine, Endrine, Heptachlore, PCB) visés par la Convention de Stockholm.",
                fullContent = """
- Art 1-2: Interdiction absolue d'importation, de détention, de vente et d'utilisation de l'Aldrine, Chlordane, Dieldrine, Endrine, Heptachlore, Mirex, Toxaphène, DDT, HCB et PCB.
- Art 3: Sanctions pénales conformément au Code de l'Environnement (Loi n° 2001-01).
- Art 4: Dérogation très strictement encadrée pour le DDT en santé publique si aucune alternative n'existe.
                """.trimIndent(),
                pageRange = "Pages 280 à 281 sur 292",
                startPage = 280,
                endPage = 281
            ),
            LegalTextEntity(
                id = "arrete_07067",
                title = "Agrément pour Activités 3D (Désinfection, Désinsectisation, Dératisation)",
                category = "Arrêté",
                referenceNumber = "Arrêté n° 07067",
                dateText = "23 Avril 2014",
                thematicTag = "Pesticides & 3D",
                summary = "Conditions de délivrance des agréments pour les prestations 3D par le Service National de l'Hygiène. Visite d'inspection, sécurité des locaux de stockage et équipements de protection (EPI).",
                fullContent = """
- Art 1-2: Visite d'inspection préalable par les agents du SNH (distance habitations, local étanche, ventilation).
- Art 4-5: Fiches de données de sécurité obligatoires, formation du personnel, visites médicales et EPI adaptés.
- Art 8: Élimination conforme des déchets liquides et solides phytosanitaires.
- Art 10: Obligation de transmission de rapports d'activité semestriels et annuels au Chef du SNH.
                """.trimIndent(),
                pageRange = "Pages 289 à 292 sur 292",
                startPage = 289,
                endPage = 292
            ),
            LegalTextEntity(
                id = "arrete_17870_pm",
                title = "Guichet Unique de l'Autorisation de Construire",
                category = "Arrêté",
                referenceNumber = "Arrêté n° 17870 PM",
                dateText = "08 Novembre 2013",
                thematicTag = "Hygiène & Salubrité",
                summary = "Création et organisation du guichet unique de l'autorisation de construire avec participation obligatoire du service chargé de l'Hygiène publique.",
                fullContent = """
- Art 1-2: Réunion périodique des services compétents (Urbanisme, Domaines, Cadastre, Hygiène Publique) pour instruction des dossiers.
- Art 4: Vérification de la conformité des plans aux normes d'aération, d'assainissement et de salubrité publique.
                """.trimIndent(),
                pageRange = "Pages 286 à 288 sur 292",
                startPage = 286,
                endPage = 288
            )
        )

        val articles = listOf(
            ArticleEntity(
                textId = "loi_83_71",
                articleNumber = "Article L.1",
                title = "Immunisation du personnel de santé",
                content = "Toute personne qui exerce dans un établissement de prévention ou de soins doit être immunisée contre la tuberculose, la diphtérie, le tétanos, les fièvres typhoïde et paratyphoïde, la poliomyélite.",
                penaltyInfo = "Suspension d'activité & sanctions de l'Article L75",
                keywords = "vaccination, immunisation, personnel médical, prophylaxie"
            ),
            ArticleEntity(
                textId = "loi_83_71",
                articleNumber = "Article L.8",
                title = "Potabilité de l'eau fournie",
                content = "Quiconque offre au public de l'eau en vue de l'alimentation humaine est tenu de s'assurer que cette eau est propre à la consommation. La fourniture ou l'utilisation d'une eau non potable pour la préparation des denrées est interdite.",
                penaltyInfo = "Amende de 9.000 à 18.000 FCFA et emprisonnement de 5 à 8 jours (Art L75)",
                keywords = "eau potable, eau insalubre, glace alimentaire, potabilité"
            ),
            ArticleEntity(
                textId = "loi_83_71",
                articleNumber = "Article L.16",
                title = "Conservation des ordures ménagères",
                content = "Dans chaque immeuble, les ordures ménagères doivent être conservées dans des poubelles réglementaires ou containers. Tout dépôt d'ordures non conforme est interdit.",
                penaltyInfo = "Amende de 1.800 à 3.000 FCFA (Art L73)",
                keywords = "poubelle, ordures, conteneur, propreté"
            ),
            ArticleEntity(
                textId = "loi_2001_01",
                articleNumber = "Article L.13",
                title = "Étude d'Impact Environnemental (EIE)",
                content = "Tout projet de construction, d'aménagement ou d'installation industrielle susceptible de porter atteinte à l'environnement doit faire l'objet d'une Étude d'Impact Environnemental préalable.",
                penaltyInfo = "Arrêt immédiat des travaux et amende de 1.000.000 à 10.000.000 FCFA",
                keywords = "EIE, environnement, impact, ICPE, pollution"
            ),
            ArticleEntity(
                textId = "loi_2009_24",
                articleNumber = "Article 8",
                title = "Obligation de raccordement à l'égout",
                content = "Les propriétaires d'immeubles riverains d'une voie publique pourvue d'un réseau public d'assainissement liquide sont tenus de se raccorder dans un délai maximal de deux ans.",
                penaltyInfo = "Mise en demeure et redevance majorée de 100%",
                keywords = "égout, assainissement, raccordement, eaux usées"
            ),
            ArticleEntity(
                textId = "loi_81_13",
                articleNumber = "Article 12",
                title = "Périmètres de protection sanitaire des eaux",
                content = "Autour de tout ouvrage de captage d'eau destinée à la consommation, il est instauré un périmètre de protection sanitaire dans lequel toute activité polluante est interdite.",
                penaltyInfo = "Saisie du matériel et amende de 100.000 à 500.000 FCFA",
                keywords = "captage, périmètre de protection, potabilité, eau"
            ),
            ArticleEntity(
                textId = "rsi_2005",
                articleNumber = "Article 19",
                title = "Capacités sanitaires aux points d'entrée",
                content = "Chaque État Partie désigne les aéroports et ports maritimes qui doivent développer les capacités de santé publique pour contrôler les vecteurs de maladies et appliquer le contrôle sanitaire.",
                penaltyInfo = "Avertissement international et fermeture temporaire du poste frontière",
                keywords = "RSI, port, aéroport, frontière, contrôle sanitaire, AIBD"
            ),
            ArticleEntity(
                textId = "conv_bamako",
                articleNumber = "Article 4",
                title = "Interdiction des importations de déchets dangereux",
                content = "Toutes les Parties interdisent l'importation de tous les déchets dangereux en Afrique en provenance de parties non africaines pour quelque raison que ce soit.",
                penaltyInfo = "Crime environnemental - Saisie du navire/véhicule et peine criminelle",
                keywords = "Bamako, déchets dangereux, interdiction, Afrique, trafic toxique"
            ),
            ArticleEntity(
                textId = "loi_65_60_code_penal",
                articleNumber = "Article 275",
                title = "Empoisonnement des eaux potables et puits",
                content = "Quiconque aura empoisonné des puits, fontaines, réservoirs ou cisternes d'eau servant à l'alimentation humaine est puni des peines répressives prévues pour le crime d'empoisonnement.",
                penaltyInfo = "Réclusion criminelle à perpétuité et confiscation des matériels",
                keywords = "Code pénal, empoisonnement, eau potable, puits, crime"
            ),
            ArticleEntity(
                textId = "loi_65_60_code_penal",
                articleNumber = "Article 194",
                title = "Outrage envers les agents assermentés de l'Hygiène",
                content = "Tout outrage fait publiquement par paroles, gestes, menaces ou écrits à un agent assermenté du Service National de l'Hygiène dans l'exercice de ses fonctions est sévèrement réprimé.",
                penaltyInfo = "Emprisonnement de 1 mois à 2 ans et amende pénal",
                keywords = "outrage, agent assermenté, SNH, force publique, délit"
            ),
            ArticleEntity(
                textId = "loi_65_61_code_procedure_penale",
                articleNumber = "Article 21",
                title = "Force probante des Procès-Verbaux (PV)",
                content = "Les Procès-Verbaux dressés par les agents assermentés du SNH et inspecteurs de l'Environnement font foi jusqu'à preuve contraire établie par écrit ou témoins.",
                penaltyInfo = "Procédure judiciaire - Transmission directe au Procureur de la République",
                keywords = "procès-verbal, PV, force probante, constatation, procédure pénale"
            )
        )

        val dictionary = listOf(
            DictionaryTermEntity(
                term = "DASRI",
                definition = "Déchets d'Activités de Soins à Risques Infectieux. Déchets contenant des micro-organismes ou leurs toxines pouvant causer des infections chez l'homme.",
                category = "Déchets Biomédicaux",
                legalReference = "Décret n° 2008-1007, Art. 3"
            ),
            DictionaryTermEntity(
                term = "SNH",
                definition = "Service National de l'Hygiène du Sénégal. Organisme militarisé relevant du Ministère de la Santé chargé du contrôle sanitaire et de l'hygiène publique.",
                category = "Institution",
                legalReference = "Loi n° 81-12 & Décret 83-028"
            ),
            DictionaryTermEntity(
                term = "ICPE",
                definition = "Installations Classées pour la Protection de l'Environnement. Usines, ateliers ou dépôts présentant des risques pour la santé, la sécurité ou l'environnement.",
                category = "Environnement",
                legalReference = "Loi n° 2001-01 (Code de l'Environnement)"
            ),
            DictionaryTermEntity(
                term = "RSI 2005",
                definition = "Règlement Sanitaire International adopté par l'OMS. Instrument juridique obligatoire visant à prévenir la propagation internationale des épidémies.",
                category = "International",
                legalReference = "RSI 2005 - OMS"
            ),
            DictionaryTermEntity(
                term = "Convention de Bâle",
                definition = "Traité international régissant le contrôle des mouvements transfrontières de déchets dangereux et exigeant le consentement préalable du pays destinataire.",
                category = "Conventions Déchets",
                legalReference = "Convention de Bâle (1989/1992)"
            ),
            DictionaryTermEntity(
                term = "Convention de Bamako",
                definition = "Convention africaine interdisant l'importation en Afrique de déchets dangereux et toxiques venus de pays développés.",
                category = "Conventions Déchets",
                legalReference = "Convention de Bamako (1991/1997)"
            ),
            DictionaryTermEntity(
                term = "POP",
                definition = "Polluants Organiques Persistants. Substances chimiques toxiques (DDT, Aldrine, PCB) accumulables et interdites par la Convention de Stockholm.",
                category = "Pesticides & Déchets",
                legalReference = "Convention de Stockholm & Arrêté 09415"
            ),
            DictionaryTermEntity(
                term = "ONAS",
                definition = "Office National de l'Assainissement du Sénégal. Établissement public chargé de la gestion des ouvrages d'assainissement collectif et des stations d'épuration.",
                category = "Assainissement",
                legalReference = "Loi n° 2009-24 (Code de l'Assainissement)"
            ),
            DictionaryTermEntity(
                term = "Périmètre de Protection",
                definition = "Zone réglementée autour d'un captage d'eau potable interdisant tout dépôt de déchet ou activité polluante.",
                category = "Eau",
                legalReference = "Loi n° 81-13 (Code de l'Eau), Art. 12"
            ),
            DictionaryTermEntity(
                term = "OPJ & APJ",
                definition = "Officiers et Agents de Police Judiciaire assermentés habilités à constater les infractions pénales et rédiger les Procès-Verbaux (PV).",
                category = "Procédure Pénale",
                legalReference = "Loi n° 65-61 (Code de Procédure Pénale), Art. 12"
            ),
            DictionaryTermEntity(
                term = "PV (Procès-Verbal)",
                definition = "Acte authentique rédigé par un agent assermenté du SNH constatant une infraction. Fait foi jusqu'à preuve du contraire.",
                category = "Procédure Pénale",
                legalReference = "Loi n° 65-61 (Code de Procédure Pénale), Art. 21"
            )
        )

        val notifications = listOf(
            NotificationItemEntity(
                id = "notif_001",
                title = "Recueil Officiel Complété par l'IA",
                message = "Base de données mise à jour avec les textes complets sur l'Hygiène, l'Environnement, l'Assainissement, l'Eau, le RSI 2005, les Conventions Déchets et le Code Pénal & Procédure Pénale du Sénégal.",
                dateText = "Aujourd'hui, 08:30",
                category = "Base de Données IA",
                isRead = false,
                relatedTextId = "loi_65_60_code_penal"
            ),
            NotificationItemEntity(
                id = "notif_004",
                title = "Intégration du Code Pénal & Procédure Pénale",
                message = "Le Code Pénal (Loi n° 65-60) et le Code de Procédure Pénale (Loi n° 65-61) du Sénégal sont désormais intégrés à la base de données du SNH.",
                dateText = "Aujourd'hui, 09:00",
                category = "Législation Pénale",
                isRead = false,
                relatedTextId = "loi_65_61_code_procedure_penale"
            ),
            NotificationItemEntity(
                id = "notif_002",
                title = "Alerte RSI 2005 & Frontières AIBD",
                message = "Surveillance sanitaire renforcée aux postes frontières maritimes et aériens conformément au Règlement Sanitaire International (RSI 2005).",
                dateText = "Hier, 14:15",
                category = "Santé Publique Intl",
                isRead = false,
                relatedTextId = "rsi_2005"
            ),
            NotificationItemEntity(
                id = "notif_003",
                title = "Rappel Conventions Déchets Toxiques",
                message = "Interdiction stricte de tout transfert transfrontalière non autorisé de déchets dangereux au Port de Dakar (Conventions de Bâle et Bamako).",
                dateText = "3 août 2026",
                category = "Environnement",
                isRead = true,
                relatedTextId = "conv_bamako"
            )
        )

        dao.insertTexts(texts)
        dao.insertArticles(articles)
        dao.insertDictionaryTerms(dictionary)
        dao.insertNotifications(notifications)
    }
}
