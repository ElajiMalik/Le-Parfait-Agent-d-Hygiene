package com.example.data.repository

import com.example.data.local.ArticleEntity
import com.example.data.local.DictionaryTermEntity
import com.example.data.local.LegalTextDao
import com.example.data.local.LegalTextEntity
import com.example.data.local.NotificationItemEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LegalRepository(private val dao: LegalTextDao) {

    // Cloud Sync State Simulation
    private val _isCloudSyncing = MutableStateFlow(false)
    val isCloudSyncing: StateFlow<Boolean> = _isCloudSyncing.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow(System.currentTimeMillis())
    val lastSyncTimestamp: StateFlow<Long> = _lastSyncTimestamp.asStateFlow()

    fun getAllTexts(): Flow<List<LegalTextEntity>> = dao.getAllLegalTexts()

    fun getTextsByCategory(category: String): Flow<List<LegalTextEntity>> {
        return if (category == "Tout" || category.isEmpty()) {
            dao.getAllLegalTexts()
        } else {
            dao.getTextsByCategory(category)
        }
    }

    fun getTextsByTag(tag: String): Flow<List<LegalTextEntity>> {
        return if (tag == "Toutes" || tag.isEmpty()) {
            dao.getAllLegalTexts()
        } else {
            dao.getTextsByTag(tag)
        }
    }

    fun getFavoriteTexts(): Flow<List<LegalTextEntity>> = dao.getFavoriteTexts()

    fun searchText(query: String): Flow<List<LegalTextEntity>> {
        return if (query.isBlank()) {
            dao.getAllLegalTexts()
        } else {
            dao.searchText(query.trim())
        }
    }

    suspend fun getTextById(textId: String): LegalTextEntity? = dao.getTextById(textId)

    suspend fun toggleFavorite(textId: String) {
        val text = dao.getTextById(textId) ?: return
        dao.updateText(text.copy(isFavorite = !text.isFavorite))
    }

    suspend fun updateUserNote(textId: String, note: String) {
        val text = dao.getTextById(textId) ?: return
        dao.updateText(text.copy(userNote = note))
    }

    fun getArticlesForText(textId: String): Flow<List<ArticleEntity>> = dao.getArticlesForText(textId)

    fun searchArticles(query: String): Flow<List<ArticleEntity>> = dao.searchArticles(query)

    fun getAllNotifications(): Flow<List<NotificationItemEntity>> = dao.getAllNotifications()

    suspend fun markNotificationAsRead(id: String) = dao.markNotificationAsRead(id)

    fun searchDictionary(query: String): Flow<List<DictionaryTermEntity>> {
        return if (query.isBlank()) dao.getAllDictionaryTerms() else dao.searchDictionary(query.trim())
    }

    suspend fun enrichDatabaseWithAiTexts(
        text: LegalTextEntity,
        articles: List<ArticleEntity>,
        terms: List<DictionaryTermEntity>
    ) {
        dao.insertText(text)
        if (articles.isNotEmpty()) {
            dao.insertArticles(articles)
        }
        if (terms.isNotEmpty()) {
            dao.insertDictionaryTerms(terms)
        }
        val notif = NotificationItemEntity(
            id = "notif_ai_" + System.currentTimeMillis(),
            title = "Nouveau texte ajouté par l'IA : ${text.title}",
            message = "L'Agent IA a fait des recherches et complété la base de données avec : ${text.title} (${text.referenceNumber}).",
            dateText = "A l'instant",
            category = "IA Base de Données",
            isRead = false,
            relatedTextId = text.id
        )
        dao.insertNotifications(listOf(notif))
    }

    suspend fun getRelevantLegalContextForAi(query: String): String {
        val trimmed = query.trim()
        val matchedTexts = mutableListOf<LegalTextEntity>()
        val matchedArticles = mutableListOf<ArticleEntity>()
        val matchedTerms = mutableListOf<DictionaryTermEntity>()

        if (trimmed.isNotBlank()) {
            val words = trimmed.lowercase()
                .replace(Regex("[^a-z0-9àâçéèêëîïôûùüÿñæœ\\s]"), " ")
                .split(Regex("\\s+"))
                .filter { it.length >= 3 && it !in setOf("quel", "quelle", "quelles", "quels", "sont", "les", "des", "une", "pour", "avec", "dans", "sur", "mot", "avez", "vous", "cette", "mais", "c'est", "infraction", "infractions", "liée", "liées", "lien") }

            val searchTerms = (listOf(trimmed) + words).distinct().filter { it.isNotBlank() }

            for (term in searchTerms) {
                val texts = dao.searchTextOnce(term)
                texts.forEach { if (matchedTexts.none { m -> m.id == it.id }) matchedTexts.add(it) }

                val articles = dao.searchArticlesOnce(term)
                articles.forEach { if (matchedArticles.none { m -> m.articleId == it.articleId }) matchedArticles.add(it) }

                val terms = dao.searchDictionaryOnce(term)
                terms.forEach { if (matchedTerms.none { m -> m.term == it.term }) matchedTerms.add(it) }
            }
        }

        if (matchedTexts.isEmpty()) {
            val allTexts = dao.getAllLegalTextsOnce()
            matchedTexts.addAll(allTexts.take(6))
        }

        val sb = StringBuilder()
        sb.append("--- EXTRAITS JURIDIQUES ET INFRACTIONS (BASE DE DONNÉES 292 PAGES SNH) ---\n\n")
        matchedTexts.take(8).forEach { text ->
            sb.append("• TEXTE OFFICIEL: ${text.title} (${text.referenceNumber}) - Catégorie: ${text.category}\n")
            sb.append("  PAGES DANS LE RECUEIL: ${text.pageRange}\n")
            sb.append("  RÉSUMÉ: ${text.summary}\n")
            val previewContent = if (text.fullContent.length > 1000) text.fullContent.take(1000) + "..." else text.fullContent
            sb.append("  CONTENU OFFICIEL & DISPOSITIONS: $previewContent\n\n")
        }

        if (matchedArticles.isNotEmpty()) {
            sb.append("• ARTICLES ET SANCTIONS SPÉCIFIQUES EXTRAITS DE LA BASE DE DONNÉES:\n")
            matchedArticles.take(10).forEach { article ->
                sb.append("  - ${article.articleNumber}: ${article.title}\n")
                sb.append("    Dispositions / Interdictions: ${article.content}\n")
                if (article.penaltyInfo.isNotBlank()) {
                    sb.append("    ⚠️ SANCTION / PEINE: ${article.penaltyInfo}\n")
                }
                sb.append("    Mots-clés associés: ${article.keywords}\n")
            }
            sb.append("\n")
        }

        if (matchedTerms.isNotEmpty()) {
            sb.append("• DÉFINITIONS DU DICTIONNAIRE JURIDIQUE SNH:\n")
            matchedTerms.take(6).forEach { term ->
                sb.append("  - ${term.term} (${term.category}): ${term.definition} [Ref: ${term.legalReference}]\n")
            }
        }

        return sb.toString()
    }

    // Cloud Sync Trigger
    suspend fun triggerCloudSync() {
        _isCloudSyncing.value = true
        kotlinx.coroutines.delay(1800) // Simulate network sync
        _lastSyncTimestamp.value = System.currentTimeMillis()
        _isCloudSyncing.value = false
    }
}
