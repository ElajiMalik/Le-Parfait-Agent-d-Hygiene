package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "legal_texts",
    indices = [
        Index("title"),
        Index("category"),
        Index("thematicTag"),
        Index("publicationYear")
    ]
)
data class LegalTextEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // "Loi", "Décret", "Arrêté", "Hygiène", "Environnement"
    val referenceNumber: String,
    val dateText: String, // Date du texte
    val thematicTag: String, // "Hygiène & Salubrité", "Alimentation", "Statut SNH", "Pesticides & 3D", "Déchets Biomédicaux", etc.
    val summary: String,
    val fullContent: String, // Contenu texte complet pour recherche rapide
    val pageRange: String = "Page 1 sur 292", // Indexation des 292 pages du recueil
    val startPage: Int = 1,
    val endPage: Int = 292,
    val isFavorite: Boolean = false,
    val userNote: String = "",
    val isRecentlyPublished: Boolean = false,
    val publicationYear: Int = 2024
)

@Entity(tableName = "articles")
data class ArticleEntity(
    @PrimaryKey(autoGenerate = true) val articleId: Long = 0,
    val textId: String,
    val articleNumber: String,
    val title: String,
    val content: String,
    val penaltyInfo: String = "",
    val keywords: String = ""
)

@Entity(tableName = "notifications")
data class NotificationItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val dateText: String,
    val category: String,
    val isRead: Boolean = false,
    val relatedTextId: String? = null
)

@Entity(tableName = "dictionary_terms")
data class DictionaryTermEntity(
    @PrimaryKey val term: String,
    val definition: String,
    val category: String,
    val legalReference: String
)
