package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AiAgentScreen
import com.example.ui.screens.FavoritesNotesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.SanctionsDictScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TextDetailScreen
import com.example.ui.screens.TextListScreen
import com.example.ui.theme.HygieneTheme
import com.example.ui.viewmodel.LegalViewModel
import com.example.ui.viewmodel.MainNavTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: LegalViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsState()

            HygieneTheme(themeMode = themeMode) {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: LegalViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val selectedTextDetail by viewModel.selectedTextDetail.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val favoriteTexts by viewModel.favoriteTexts.collectAsState()

    var isViewingNotifications by remember { mutableStateOf(false) }

    val unreadNotifsCount = notifications.count { !it.isRead }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (selectedTextDetail == null && !isViewingNotifications) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.HOME,
                        onClick = { viewModel.setTab(MainNavTab.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Accueil") },
                        label = { Text("Accueil") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.LIBRARY,
                        onClick = { viewModel.setTab(MainNavTab.LIBRARY) },
                        icon = { Icon(Icons.Default.MenuBook, contentDescription = "Textes") },
                        label = { Text("Textes") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_library")
                    )

                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.AI_AGENT,
                        onClick = { viewModel.setTab(MainNavTab.AI_AGENT) },
                        icon = { Icon(Icons.Default.SmartToy, contentDescription = "Agent IA") },
                        label = { Text("Agent IA") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_ai_agent")
                    )

                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.SANCTIONS_DICT,
                        onClick = { viewModel.setTab(MainNavTab.SANCTIONS_DICT) },
                        icon = { Icon(Icons.Default.Gavel, contentDescription = "Sanctions") },
                        label = { Text("Sanctions") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_dictionary")
                    )

                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.FAVORITES_NOTES,
                        onClick = { viewModel.setTab(MainNavTab.FAVORITES_NOTES) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (favoriteTexts.isNotEmpty()) {
                                        Badge { Text("${favoriteTexts.size}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Bookmark, contentDescription = "Favoris")
                            }
                        },
                        label = { Text("Favoris") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_favorites")
                    )

                    NavigationBarItem(
                        selected = selectedTab == MainNavTab.SETTINGS,
                        onClick = { viewModel.setTab(MainNavTab.SETTINGS) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (unreadNotifsCount > 0) {
                                        Badge { Text("$unreadNotifsCount") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Settings, contentDescription = "Réglages")
                            }
                        },
                        label = { Text("Réglages") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        if (selectedTextDetail != null) {
            TextDetailScreen(
                textItem = selectedTextDetail!!,
                viewModel = viewModel,
                onBack = { viewModel.closeTextDetail() },
                modifier = Modifier.padding(innerPadding)
            )
        } else if (isViewingNotifications) {
            NotificationsScreen(
                viewModel = viewModel,
                onBack = { isViewingNotifications = false },
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            when (selectedTab) {
                MainNavTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToNotifications = { isViewingNotifications = true },
                    modifier = Modifier.padding(innerPadding)
                )
                MainNavTab.LIBRARY -> TextListScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
                MainNavTab.AI_AGENT -> AiAgentScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
                MainNavTab.SANCTIONS_DICT -> SanctionsDictScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
                MainNavTab.FAVORITES_NOTES -> FavoritesNotesScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
                MainNavTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}

